package com.example.termux_hup

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
